# Dolars$ Game Mode

App Android (Kotlin) untuk memantau kondisi HP saat main game, plus jalan pintas ke pengaturan HP, halaman donasi QRIS, dan Thanks to.

App ini tidak mengubah performa HP. Semua angka di menu pantau perangkat diambil langsung dari sistem Android.

## Isi menu
- Pantau perangkat: memori, penyimpanan, dan baterai (persen, status charge, suhu baterai)
- Jalan pintas dan tips: buka pengaturan layar, penghemat baterai, dan daftar aplikasi
- Dukung pengembang: kode QRIS (sukarela)
- Thanks to: daftar bisa diedit di `res/values/strings.xml` (bagian `thanks_*`)
- Tentang app

## Mengganti data
- Nama dan teks: `res/values/strings.xml`
- Kode QRIS: ganti file `res/drawable/qris_donasi.jpg`
- Foto profil dan banner: ganti file `res/drawable/pfp_dolars.jpg` dan `res/drawable/banner_dolars.jpg`
- Warna: `res/values/colors.xml`

## Build dari HP
Sama seperti DolarsThemes: buat repository baru, buat file `.github/workflows/build.yml`, upload `DolarsGameMode.zip`, lalu jalankan workflow **Build APK** dari tab Actions.

## Belum ada di versi ini
Dashboard admin, tambah member, tambah admin, dan kirim notifikasi. Fitur ini butuh server (misalnya Firebase), jadi dibuat terpisah.
