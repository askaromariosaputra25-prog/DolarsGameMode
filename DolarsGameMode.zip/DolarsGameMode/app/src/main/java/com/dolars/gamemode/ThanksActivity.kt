package com.dolars.gamemode

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/** Daftar Thanks to diisi di res/values/strings.xml (bagian thanks_*). */
class ThanksActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_thanks)
    }
}
