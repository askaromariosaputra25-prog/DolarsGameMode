package com.dolars.gamemode

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.os.StatFs
import android.text.format.Formatter
import androidx.appcompat.app.AppCompatActivity
import com.dolars.gamemode.databinding.ActivityMonitorBinding

/** Menampilkan kondisi HP yang diambil langsung dari sistem. Tidak ada angka yang dikarang. */
class MonitorActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMonitorBinding
    private val handler = Handler(Looper.getMainLooper())

    private val refresher = object : Runnable {
        override fun run() {
            updateStats()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMonitorBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    override fun onResume() {
        super.onResume()
        handler.post(refresher)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(refresher)
    }

    private fun updateStats() {
        updateRam()
        updateStorage()
        updateBattery()
    }

    private fun updateRam() {
        val am = getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)

        val used = info.totalMem - info.availMem
        val percent = (used * 100 / info.totalMem).toInt()

        binding.ramValue.text = "${size(used)} dari ${size(info.totalMem)} ($percent%)"
        binding.ramBar.progress = percent
        binding.ramHint.text = if (percent >= 85) {
            "Memori hampir penuh. Tutup app yang tidak dipakai sebelum main."
        } else {
            "Memori masih lega."
        }
    }

    private fun updateStorage() {
        val stat = StatFs(Environment.getDataDirectory().path)
        val total = stat.totalBytes
        val used = total - stat.availableBytes
        val percent = (used * 100 / total).toInt()

        binding.storageValue.text = "${size(used)} dari ${size(total)} ($percent%)"
        binding.storageBar.progress = percent
        binding.storageHint.text = if (percent >= 90) {
            "Penyimpanan hampir penuh. Hapus file yang tidak perlu."
        } else {
            "Penyimpanan masih cukup."
        }
    }

    private fun updateBattery() {
        val intent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return

        val level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
        val scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100).coerceAtLeast(1)
        val percent = level * 100 / scale
        val tempC = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, 0) / 10.0
        val status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        val charging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
            status == BatteryManager.BATTERY_STATUS_FULL

        val chargeText = if (charging) "sedang di-charge" else "tidak di-charge"
        val tempText = String.format("%.1f °C", tempC)

        binding.batteryValue.text = "$percent%, $chargeText, suhu $tempText"
        binding.batteryBar.progress = percent
        binding.batteryHint.text = when {
            tempC >= 42 -> "Suhu baterai cukup tinggi. Istirahatkan HP sebentar sebelum lanjut main."
            tempC >= 38 -> "Suhu masih wajar, tapi mulai hangat."
            else -> "Suhu baterai normal."
        }
    }

    private fun size(bytes: Long): String = Formatter.formatFileSize(this, bytes)
}
