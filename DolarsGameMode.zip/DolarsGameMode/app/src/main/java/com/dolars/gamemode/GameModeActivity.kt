package com.dolars.gamemode

import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.dolars.gamemode.databinding.ActivityGameModeBinding

/** Jalan pintas ke menu pengaturan HP. Tidak mengubah pengaturan itu sendiri. */
class GameModeActivity : AppCompatActivity() {

    private lateinit var binding: ActivityGameModeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityGameModeBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnDisplay.setOnClickListener { openSettings(Settings.ACTION_DISPLAY_SETTINGS) }
        binding.btnBattery.setOnClickListener { openSettings(Settings.ACTION_BATTERY_SAVER_SETTINGS) }
        binding.btnApps.setOnClickListener { openSettings(Settings.ACTION_MANAGE_ALL_APPLICATIONS_SETTINGS) }
    }

    private fun openSettings(action: String) {
        try {
            startActivity(Intent(action))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, "Menu ini tidak tersedia di HP kamu", Toast.LENGTH_SHORT).show()
        }
    }
}
