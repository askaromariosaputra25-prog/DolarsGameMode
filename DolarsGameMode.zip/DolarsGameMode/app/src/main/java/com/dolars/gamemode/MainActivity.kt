package com.dolars.gamemode

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.dolars.gamemode.databinding.ActivityMainBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnMonitor.setOnClickListener { openScreen(MonitorActivity::class.java) }
        binding.btnGameMode.setOnClickListener { openScreen(GameModeActivity::class.java) }
        binding.btnDonate.setOnClickListener { openScreen(DonateActivity::class.java) }
        binding.btnThanks.setOnClickListener { openScreen(ThanksActivity::class.java) }
        binding.btnAbout.setOnClickListener { showAbout() }
    }

    private fun openScreen(target: Class<*>) {
        startActivity(Intent(this, target))
    }

    private fun showAbout() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Tentang")
            .setMessage(
                "Dolars\$ Game Mode versi 1.0\n\n" +
                    "Dibuat oleh Askaa.\n\n" +
                    "App ini membantu kamu memantau kondisi HP saat main game. " +
                    "App ini tidak mengubah performa HP dan tidak menjanjikan HP jadi lebih cepat."
            )
            .setPositiveButton("Oke", null)
            .show()
    }
}
